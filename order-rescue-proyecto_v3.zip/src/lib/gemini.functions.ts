import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  tienda: z.string().min(1),
  original: z.string().min(1),
  sustituto: z.string().min(1),
  margen: z.number().min(0).max(100),
});

export const generarNotificacionIA = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error(
        "GEMINI_API_KEY no está configurada. Agrega el secreto en Lovable para activar la IA."
      );
    }

    const prompt = `Eres un asistente inteligente de logística y ventas para una plataforma de distribución en México.
Tu objetivo es ayudar a rescatar un pedido de una tiendita de la esquina de manera empática y persuasiva.

Datos actuales del problema:
- Nombre de la tienda: "${data.tienda}"
- Producto original agotado: "${data.original}"
- Producto sugerido para sustitución: "${data.sustituto}"
- Beneficio para el tendero: Al aceptar este cambio, obtiene un ${data.margen}% más de margen de ganancia.

Instrucciones de redacción:
- Escribe una notificación push corta (máximo 3 frases).
- Usa un tono muy mexicano, amigable, respetuoso (háblale de 'usted') pero profesional.
- Destaca el beneficio económico directo para que acepte el cambio de inmediato desde la app.
- No agregues introducciones, saludos de IA, ni asteriscos de formato; entrega directamente el mensaje limpio.`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
        }),
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Gemini API error (${response.status}): ${errText}`);
    }

    const json = (await response.json()) as {
      candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    };
    const text =
      json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("").trim() ?? "";

    if (!text) throw new Error("Respuesta vacía de Gemini.");
    return { mensaje: text };
  });
