import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState, useEffect, useRef } from "react";
import {
  ArrowLeft,
  Phone,
  Video,
  MoreVertical,
  Check,
  CheckCheck,
  Signal,
  Wifi,
  BatteryFull,
  Smartphone,
  Sparkles,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { generarNotificacionIA } from "@/lib/gemini.functions";

export const Route = createFileRoute("/whatsapp")({
  head: () => ({
    meta: [
      { title: "Order Rescue · Simulación WhatsApp" },
      {
        name: "description",
        content:
          "Simulación del flujo proactivo de WhatsApp Business para que el cliente B2B controle sustituciones de su pedido.",
      },
    ],
  }),
  component: WhatsAppPage,
});

type Option = "sabor" | "tamano" | "rechazo";

interface Msg {
  id: number;
  from: "bot" | "user";
  text: string;
  time: string;
}

const optionLabels: Record<Option, string> = {
  sabor: "Cambiar faltante por Coca-Cola Zero / Light",
  tamano: "Cambiar por presentación en Lata de 355ml",
  rechazo: "No sustituir (Descontar del total de la factura)",
};

const confirmations: Record<Option, string> = {
  sabor:
    "¡Entendido, Don Chuy! 🥤 Hemos actualizado tu orden en el CEDIS: las cajas faltantes se sustituirán por Coca-Cola Zero / Light. Tu repartidor lo confirmará al entregar.",
  tamano:
    "¡Listo! 📦 Hemos cambiado las cajas faltantes por presentación en lata de 355ml. Tu factura se ajustará automáticamente al precio correspondiente.",
  rechazo:
    "Perfecto. ❌ No se realizará ninguna sustitución. Las cajas faltantes serán descontadas del total de tu factura. Recibirás el comprobante actualizado por este medio.",
};

const initialMsgs: Msg[] = [
  {
    id: 1,
    from: "bot",
    text:
      "¡Hola Don Chuy! 👋 Le escribimos de *Arca Continental — Coca-Cola FEMSA*.",
    time: "10:42",
  },
  {
    id: 2,
    from: "bot",
    text:
      "El inventario de *Coca-Cola Original 600ml* está bajo y hay un *70% de riesgo* de que su pedido sufra una sustitución automática en bodega. 🚨\n\nQueremos darle el control: elija cómo prefiere recibir las cajas faltantes 👇",
    time: "10:42",
  },
];

function WhatsAppPage() {
  const [messages, setMessages] = useState<Msg[]>(initialMsgs);
  const [chosen, setChosen] = useState<Option | null>(null);
  const [typing, setTyping] = useState(false);
  const [iaLoading, setIaLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const callGemini = useServerFn(generarNotificacionIA);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const handleGenerarIA = async () => {
    setIaLoading(true);
    setTyping(true);
    try {
      const res = await callGemini({
        data: {
          tienda: "Don Chuy",
          original: "Coca-Cola Original 600ml",
          sustituto: "Coca-Cola Original Lata 355ml",
          margen: 8,
        },
      });
      const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      setMessages((m) => [
        ...m,
        { id: m.length + 1, from: "bot", text: `🤖 *Sugerencia IA:* ${res.mensaje}`, time: now },
      ]);
      toast.success("Mensaje generado con Gemini");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Error generando con IA");
    } finally {
      setTyping(false);
      setIaLoading(false);
    }
  };

  const handleChoose = (opt: Option) => {
    if (chosen) return;
    setChosen(opt);
    const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    setMessages((m) => [
      ...m,
      { id: m.length + 1, from: "user", text: optionLabels[opt], time: now },
    ]);
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMessages((m) => [
        ...m,
        {
          id: m.length + 1,
          from: "bot",
          text: confirmations[opt],
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    }, 1400);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Smartphone className="h-3.5 w-3.5" />
            Vista del Cliente B2B
          </div>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Simulación de WhatsApp Business
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Mensaje proactivo enviado a Don Chuy antes de que la sustitución ocurra en bodega.
          </p>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[auto_1fr]">
        {/* Phone frame */}
        <div className="mx-auto">
          <PhoneFrame>
            {/* WhatsApp header */}
            <div className="flex items-center gap-3 bg-whatsapp px-3 py-2.5 text-white">
              <ArrowLeft className="h-5 w-5 shrink-0" />
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold">
                AC
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold leading-tight">
                  Arca Continental
                </div>
                <div className="text-[10px] opacity-90">en línea · Business ✓</div>
              </div>
              <Video className="h-5 w-5" />
              <Phone className="h-4 w-4" />
              <MoreVertical className="h-5 w-5" />
            </div>

            {/* Chat body */}
            <div
              ref={scrollRef}
              className="relative h-[500px] overflow-y-auto bg-whatsapp-bg px-3 py-4"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 1px 1px, color-mix(in oklab, var(--whatsapp) 12%, transparent) 1px, transparent 0)",
                backgroundSize: "20px 20px",
              }}
            >
              <div className="mx-auto mb-3 w-fit rounded-md bg-white/80 px-3 py-1 text-[10px] text-muted-foreground shadow-sm">
                Hoy
              </div>

              <div className="space-y-2">
                {messages.map((m) => (
                  <Bubble key={m.id} msg={m} />
                ))}

                {/* Mini-survey buttons (only before selection) */}
                {!chosen && (
                  <div className="ml-1 max-w-[85%] space-y-1.5 pt-1">
                    <SurveyButton
                      tag="A"
                      label="Cambiar por Coca-Cola Zero / Light"
                      sub="Sustitución por sabor"
                      onClick={() => handleChoose("sabor")}
                    />
                    <SurveyButton
                      tag="B"
                      label="Cambiar por presentación en Lata 355ml"
                      sub="Sustitución por tamaño"
                      onClick={() => handleChoose("tamano")}
                    />
                    <SurveyButton
                      tag="C"
                      label="No sustituir · Descontar de la factura"
                      sub="Rechazo proactivo"
                      onClick={() => handleChoose("rechazo")}
                      variant="destructive"
                    />
                  </div>
                )}

                {typing && (
                  <div className="ml-1 inline-flex items-center gap-1.5 rounded-2xl bg-white px-3 py-2 shadow-sm">
                    <Dot delay="0s" />
                    <Dot delay="0.15s" />
                    <Dot delay="0.3s" />
                  </div>
                )}
              </div>
            </div>

            {/* Input bar */}
            <div className="flex items-center gap-2 border-t border-border bg-card px-3 py-2">
              <div className="flex-1 rounded-full bg-muted px-4 py-2 text-xs text-muted-foreground">
                Mensaje
              </div>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-whatsapp text-white">
                <Phone className="h-4 w-4" />
              </div>
            </div>
          </PhoneFrame>
        </div>

        {/* Side panel */}
        <div className="space-y-4">
          <div className="rounded-xl border border-primary/30 bg-primary/5 p-5">
            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <Sparkles className="h-4 w-4 text-primary" />
              Mensaje persuasivo con Gemini IA
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
              Genera una notificación push 100% mexicana, empática y persuasiva usando Gemini 2.5
              Flash, con base en el producto agotado, el sustituto sugerido y el margen extra.
            </p>
            <Button
              onClick={handleGenerarIA}
              disabled={iaLoading}
              className="mt-3 w-full"
              size="sm"
            >
              {iaLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generando…
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generar con Gemini
                </>
              )}
            </Button>
          </div>

          <InfoCard
            title="¿Qué está pasando?"
            body="Antes de despachar el pedido, el sistema detectó inventario insuficiente y notificó al cliente vía WhatsApp Business. El cliente decide la sustitución, no la bodega."
          />
          <InfoCard
            title="Beneficio para Arca Continental"
            body="Se reduce la tasa de sustitución no autorizada, mejora la experiencia del cliente B2B y se protege el inventario crítico del CEDIS."
          />
          <InfoCard
            title="Beneficio para Don Chuy"
            body="Tiene control total sobre lo que recibe en su tienda. Sin sorpresas en la entrega ni reclamos posteriores con el repartidor."
          />
          {chosen && (
            <div className="rounded-xl border border-success/30 bg-success/10 p-4 text-sm text-success">
              <div className="font-semibold">✓ Decisión registrada</div>
              <div className="mt-1 text-success/90">
                La orden fue actualizada en el CEDIS con la preferencia del cliente.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative w-[340px] rounded-[2.5rem] border-[10px] border-neutral-900 bg-neutral-900 shadow-2xl">
      {/* notch */}
      <div className="absolute left-1/2 top-0 z-10 h-5 w-28 -translate-x-1/2 rounded-b-2xl bg-neutral-900" />
      <div className="overflow-hidden rounded-[1.8rem] bg-card">
        {/* Status bar */}
        <div className="flex items-center justify-between bg-whatsapp px-4 pt-2.5 pb-1 text-[10px] text-white">
          <span className="font-semibold">9:41</span>
          <div className="flex items-center gap-1">
            <Signal className="h-3 w-3" />
            <Wifi className="h-3 w-3" />
            <BatteryFull className="h-3.5 w-3.5" />
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}

function Bubble({ msg }: { msg: Msg }) {
  const isBot = msg.from === "bot";
  // Render basic *bold* markdown
  const parts = msg.text.split(/(\*[^*]+\*)/g);
  return (
    <div className={cn("flex", isBot ? "justify-start" : "justify-end")}>
      <div
        className={cn(
          "relative max-w-[85%] whitespace-pre-line rounded-2xl px-3 py-2 text-[13px] leading-snug shadow-sm",
          isBot
            ? "rounded-tl-sm bg-white text-foreground"
            : "rounded-tr-sm bg-whatsapp-bubble text-foreground"
        )}
      >
        {parts.map((p, i) =>
          p.startsWith("*") && p.endsWith("*") ? (
            <strong key={i}>{p.slice(1, -1)}</strong>
          ) : (
            <span key={i}>{p}</span>
          )
        )}
        <div className="mt-1 flex items-center justify-end gap-1 text-[9px] text-muted-foreground">
          {msg.time}
          {!isBot &&
            (Math.random() > -1 ? (
              <CheckCheck className="h-3 w-3 text-whatsapp" />
            ) : (
              <Check className="h-3 w-3" />
            ))}
        </div>
      </div>
    </div>
  );
}

function SurveyButton({
  tag,
  label,
  sub,
  onClick,
  variant = "default",
}: {
  tag: string;
  label: string;
  sub: string;
  onClick: () => void;
  variant?: "default" | "destructive";
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "group flex w-full items-center gap-3 rounded-xl border bg-white px-3 py-2.5 text-left shadow-sm transition-all hover:shadow-md active:scale-[0.98]",
        variant === "destructive"
          ? "border-primary/30 hover:border-primary hover:bg-primary/5"
          : "border-whatsapp/30 hover:border-whatsapp hover:bg-whatsapp/5"
      )}
    >
      <div
        className={cn(
          "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white",
          variant === "destructive" ? "bg-primary" : "bg-whatsapp"
        )}
      >
        {tag}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-[12px] font-semibold text-foreground">{label}</div>
        <div className="truncate text-[10px] text-muted-foreground">{sub}</div>
      </div>
    </button>
  );
}

function Dot({ delay }: { delay: string }) {
  return (
    <span
      className="h-1.5 w-1.5 animate-bounce rounded-full bg-muted-foreground"
      style={{ animationDelay: delay }}
    />
  );
}

function InfoCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}
