import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Building2,
  AlertTriangle,
  TrendingUp,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertCard, type AlertProduct } from "@/components/dashboard/AlertCard";
import { AnalysisChart } from "@/components/dashboard/AnalysisChart";
import cedisData from "@/data/cedis.json";
import catalog from "@/data/catalog.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Order Rescue · Vista CEDIS" },
      {
        name: "description",
        content:
          "Panel del Supervisor de Bodega para prevenir sustituciones automáticas en los CEDIS 3501, 3804 y 3810 de Arca Continental.",
      },
    ],
  }),
  component: DashboardPage,
});

const cedisOptions: { value: keyof typeof cedisData; label: string }[] = [
  { value: "3501", label: "CEDIS 3501" },
  { value: "3804", label: "CEDIS 3804" },
  { value: "3810", label: "CEDIS 3810" },
];

const STOCK_PER_RED = 40; // demo stock value (cajas) per producto rojo

function DashboardPage() {
  const [cedis, setCedis] = useState<keyof typeof cedisData>("3804");
  const detail = cedisData[cedis];

  // Build top-3 alerts: intersect global rojos with SKUs present in this CEDIS,
  // using global subs as "pedidos esperados".
  const alerts: AlertProduct[] = useMemo(() => {
    const inCedis = new Set(detail.skus.map((s) => s.sku));
    const globalRed = catalog.items
      .filter((i) => i.riesgo === "rojo" && inCedis.has(i.sku))
      .sort((a, b) => b.subs - a.subs);
    return globalRed.slice(0, 3).map((i) => ({
      sku: String(i.sku),
      name: i.nombre,
      presentation: i.unidad,
      risk: Math.round((i.subs / catalog.maxSubs) * 100),
      stock: STOCK_PER_RED,
      expectedOrders: i.subs,
    }));
  }, [detail]);

  const avgTop3 =
    alerts.length === 0
      ? 0
      : Math.round(alerts.reduce((s, a) => s + a.risk, 0) / alerts.length);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <Building2 className="h-3.5 w-3.5" />
            Vista General del CEDIS
          </div>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Panel del Supervisor de Bodega
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Monitorea inventario y previene sustituciones automáticas · CEDIS {cedis} ·{" "}
            {detail.total} sustituciones atribuidas
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground">CEDIS:</span>
          <Select value={cedis} onValueChange={(v) => setCedis(v as keyof typeof cedisData)}>
            <SelectTrigger className="w-[280px] bg-card">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {cedisOptions.map((c) => (
                <SelectItem key={c.value} value={c.value}>
                  {c.label} · {cedisData[c.value].total} sustituciones
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <KPI
          label="SKUs en rojo"
          value={String(catalog.counts.rojo)}
          icon={AlertTriangle}
          tone="primary"
        />
        <KPI
          label="Total sustituciones"
          value={catalog.totalSubs.toLocaleString()}
          icon={TrendingUp}
        />
        <KPI
          label="Riesgo promedio top 3"
          value={`${avgTop3}%`}
          icon={TrendingUp}
          tone="warning"
        />
        <KPI
          label="Productos analizados"
          value={String(catalog.items.length)}
          icon={ShieldCheck}
          tone="success"
        />
      </div>

      <section className="mt-8">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-2 w-2 animate-pulse rounded-full bg-primary" />
            <h2 className="text-lg font-semibold">Alertas Críticas de Inventario</h2>
            <span className="ml-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-semibold text-primary">
              Top {alerts.length} de {catalog.counts.rojo} en rojo
            </span>
          </div>
          <Link
            to="/catalogo"
            className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
          >
            Ver catálogo completo
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {alerts.map((p) => (
            <AlertCard key={p.sku} product={p} />
          ))}
        </div>
      </section>

      <section className="mt-8">
        <AnalysisChart />
      </section>
    </div>
  );
}

function KPI({
  label,
  value,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  tone?: "primary" | "warning" | "success" | "default";
}) {
  const toneStyles = {
    primary: "bg-primary/10 text-primary",
    warning: "bg-warning/15 text-warning-foreground",
    success: "bg-success/15 text-success",
    default: "bg-secondary text-secondary-foreground",
  }[tone];

  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
        <div className={`flex h-7 w-7 items-center justify-center rounded-md ${toneStyles}`}>
          <Icon className="h-3.5 w-3.5" />
        </div>
      </div>
      <div className="mt-2 text-2xl font-bold tracking-tight">{value}</div>
    </div>
  );
}
