import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Filter, AlertTriangle, Search, Bell, Loader2, CheckCircle2, Megaphone } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import catalog from "@/data/catalog.json";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { generarNotificacionIA } from "@/lib/gemini.functions";

type Riesgo = "rojo" | "amarillo" | "verde";
type Item = (typeof catalog.items)[number];

export const Route = createFileRoute("/catalogo")({
  head: () => ({
    meta: [
      { title: "Catálogo de Riesgo · Order Rescue" },
      {
        name: "description",
        content:
          "Probabilidad de sustitución por SKU clasificada tipo semáforo, basada en sustituciones reales del dataset de Arca Continental.",
      },
    ],
  }),
  component: CatalogoPage,
});

const FILTERS: { id: "todos" | Riesgo; label: (n: Record<string, number>) => string }[] = [
  { id: "todos", label: (n) => `Todos (${n.todos})` },
  { id: "rojo", label: (n) => `Rojo (${n.rojo})` },
  { id: "amarillo", label: (n) => `Amarillo (${n.amarillo})` },
  { id: "verde", label: (n) => `Verde (${n.verde})` },
];

function CatalogoPage() {
  const items = catalog.items as Item[];
  const [filter, setFilter] = useState<"todos" | Riesgo>("todos");
  const [query, setQuery] = useState("");
  const [alertedSkus, setAlertedSkus] = useState<Set<string>>(new Set());
  const [loadingSku, setLoadingSku] = useState<string | null>(null);
  const [bulkLoading, setBulkLoading] = useState(false);
  const callGemini = useServerFn(generarNotificacionIA);

  const alertSku = async (item: Item) => {
    try {
      const res = await callGemini({
        data: {
          tienda: "Don Chuy",
          original: item.nombre,
          sustituto: `${item.nombre.split(" ").slice(0, 2).join(" ")} (alternativa)`,
          margen: 8,
        },
      });
      setAlertedSkus((prev) => new Set(prev).add(item.sku));
      toast.success(`WhatsApp enviado · SKU ${item.sku}`, {
        description: res.mensaje.slice(0, 120) + (res.mensaje.length > 120 ? "…" : ""),
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Error al alertar");
      throw err;
    }
  };

  const handleAlertOne = async (item: Item) => {
    setLoadingSku(item.sku);
    try {
      await alertSku(item);
    } catch {
      /* toast shown */
    } finally {
      setLoadingSku(null);
    }
  };

  const counts = useMemo(
    () => ({
      todos: items.length,
      rojo: catalog.counts.rojo,
      amarillo: catalog.counts.amarillo,
      verde: catalog.counts.verde,
    }),
    [items.length]
  );

  const rojos = useMemo(() => items.filter((i) => i.riesgo === "rojo"), [items]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((i) => {
      if (filter !== "todos" && i.riesgo !== filter) return false;
      if (!q) return true;
      return (
        String(i.sku).toLowerCase().includes(q) ||
        i.nombre.toLowerCase().includes(q) ||
        i.unidad.toLowerCase().includes(q)
      );
    });
  }, [items, filter, query]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
        <Filter className="h-3.5 w-3.5" />
        Catálogo de Productos
      </div>
      <h1 className="mt-1 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
        Probabilidad de sustitución por SKU
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {items.length} productos analizados · clasificación tipo semáforo basada en{" "}
        {catalog.totalSubs.toLocaleString()} sustituciones reales registradas en el dataset.
      </p>

      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
        <RiskCard
          tone="red"
          label="Riesgo alto"
          value={counts.rojo}
          hint="≥ 80 sustituciones"
        />
        <RiskCard
          tone="yellow"
          label="Riesgo medio"
          value={counts.amarillo}
          hint="20–79 sustituciones"
        />
        <RiskCard
          tone="green"
          label="Riesgo bajo"
          value={counts.verde}
          hint="< 20 sustituciones"
        />
      </div>

      {rojos.length > 0 && (
        <section className="mt-8 rounded-2xl border-2 border-risk-red/30 bg-risk-red-bg/60 p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-risk-red" />
              <h2 className="text-lg font-semibold text-foreground">
                Productos en Rojo · Atención inmediata
              </h2>
              <span className="ml-1 inline-flex h-6 min-w-[1.5rem] items-center justify-center rounded-full bg-risk-red px-2 text-xs font-semibold text-primary-foreground">
                {rojos.length}
              </span>
            </div>
            <Button
              onClick={async () => {
                setBulkLoading(true);
                let ok = 0;
                let fail = 0;
                for (const item of rojos) {
                  try {
                    await alertSku(item);
                    ok++;
                  } catch {
                    fail++;
                  }
                }
                setBulkLoading(false);
                toast.success(`Alertas masivas enviadas`, {
                  description: `${ok} clientes notificados${fail ? ` · ${fail} fallaron` : ""}.`,
                });
              }}
              disabled={bulkLoading}
              className="gap-2"
            >
              {bulkLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Enviando alertas…
                </>
              ) : (
                <>
                  <Megaphone className="h-4 w-4" />
                  Alertar a TODOS los clientes ({rojos.length})
                </>
              )}
            </Button>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {rojos.map((p) => (
              <RedProductCard
                key={p.sku}
                item={p}
                maxSubs={catalog.maxSubs}
                alerted={alertedSkus.has(p.sku)}
                loading={loadingSku === p.sku}
                onAlert={() => handleAlertOne(p)}
              />
            ))}
          </div>
        </section>
      )}

      <section className="mt-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex rounded-md border border-border bg-muted/40 p-1">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  "rounded px-3 py-1.5 text-xs font-medium transition-colors",
                  filter === f.id
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {f.label(counts)}
              </button>
            ))}
          </div>
          <div className="relative w-full max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar SKU o nombre…"
              className="pl-9"
            />
          </div>
        </div>

        <div className="mt-4 overflow-hidden rounded-xl border border-border bg-card shadow-sm">
          <div className="grid grid-cols-[130px_60px_minmax(0,1fr)_120px_100px_160px_170px] gap-3 border-b border-border bg-muted/40 px-4 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            <div>Riesgo</div>
            <div>SKU</div>
            <div>Producto</div>
            <div>Unidad</div>
            <div className="text-right">Sustituciones</div>
            <div>Probabilidad relativa</div>
            <div className="text-center">Acción</div>
          </div>
          <div className="max-h-[520px] overflow-y-auto divide-y divide-border">
            {filtered.slice(0, 400).map((p) => (
              <Row
                key={p.sku}
                item={p}
                maxSubs={catalog.maxSubs}
                alerted={alertedSkus.has(p.sku)}
                loading={loadingSku === p.sku}
                onAlert={() => handleAlertOne(p)}
              />
            ))}
            {filtered.length === 0 && (
              <div className="px-4 py-12 text-center text-sm text-muted-foreground">
                Sin resultados para “{query}”.
              </div>
            )}
          </div>
          {filtered.length > 400 && (
            <div className="border-t border-border bg-muted/30 px-4 py-2 text-center text-[11px] text-muted-foreground">
              Mostrando 400 de {filtered.length}. Refina la búsqueda para ver más.
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function RiskCard({
  tone,
  label,
  value,
  hint,
}: {
  tone: "red" | "yellow" | "green";
  label: string;
  value: number;
  hint: string;
}) {
  const styles = {
    red: { wrap: "border-risk-red/30 bg-risk-red-bg/60", dot: "bg-risk-red", text: "text-risk-red" },
    yellow: {
      wrap: "border-risk-yellow/30 bg-risk-yellow-bg/60",
      dot: "bg-risk-yellow",
      text: "text-foreground",
    },
    green: {
      wrap: "border-risk-green/30 bg-risk-green-bg/70",
      dot: "bg-risk-green",
      text: "text-risk-green",
    },
  }[tone];
  return (
    <div className={cn("rounded-2xl border-2 p-5", styles.wrap)}>
      <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        <span className={cn("h-2 w-2 rounded-full", styles.dot)} />
        {label}
      </div>
      <div className={cn("mt-3 text-4xl font-bold tracking-tight", styles.text)}>{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}

function RedProductCard({
  item,
  maxSubs,
  alerted,
  loading,
  onAlert,
}: {
  item: Item;
  maxSubs: number;
  alerted: boolean;
  loading: boolean;
  onAlert: () => void;
}) {
  const pct = Math.round((item.subs / maxSubs) * 100);
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
            SKU {item.sku}
          </div>
          <div className="truncate text-sm font-semibold text-foreground">{item.nombre}</div>
          <div className="text-xs text-muted-foreground">{item.unidad}</div>
        </div>
        <span className="inline-flex h-7 min-w-[2rem] items-center justify-center rounded-md bg-risk-red px-2 text-xs font-bold text-primary-foreground">
          {item.subs}
        </span>
      </div>
      <div className="mt-3">
        <div className="h-1.5 w-full rounded-full bg-muted">
          <div className="h-full rounded-full bg-risk-red" style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-1.5 text-right text-[11px] text-muted-foreground">
          {pct.toFixed(1)}% del SKU más sustituido
        </div>
      </div>
      <div className="mt-3">
        {alerted ? (
          <div className="flex items-center justify-center gap-2 rounded-md border border-success/30 bg-success/10 px-2 py-1.5 text-xs font-medium text-success">
            <CheckCircle2 className="h-3.5 w-3.5" />
            Cliente alertado
          </div>
        ) : (
          <Button onClick={onAlert} disabled={loading} size="sm" className="w-full gap-2">
            {loading ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Enviando…
              </>
            ) : (
              <>
                <Bell className="h-3.5 w-3.5" />
                Alertar al cliente
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}

function Row({
  item,
  maxSubs,
  alerted,
  loading,
  onAlert,
}: {
  item: Item;
  maxSubs: number;
  alerted: boolean;
  loading: boolean;
  onAlert: () => void;
}) {
  const pct = (item.subs / maxSubs) * 100;
  const styles =
    item.riesgo === "rojo"
      ? { badge: "bg-risk-red-bg text-risk-red border-risk-red/30", bar: "bg-risk-red" }
      : item.riesgo === "amarillo"
        ? {
            badge: "bg-risk-yellow-bg text-risk-yellow border-risk-yellow/30",
            bar: "bg-risk-yellow",
          }
        : {
            badge: "bg-risk-green-bg text-risk-green border-risk-green/30",
            bar: "bg-risk-green",
          };
  return (
    <div className="grid grid-cols-[130px_60px_minmax(0,1fr)_120px_100px_160px_170px] items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted/40">
      <div>
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider",
            styles.badge
          )}
        >
          <span className={cn("h-1.5 w-1.5 rounded-full", styles.bar)} />
          Riesgo {item.riesgo}
        </span>
      </div>
      <div className="font-mono text-xs text-muted-foreground">{item.sku}</div>
      <div className="truncate font-medium text-foreground">{item.nombre}</div>
      <div className="truncate text-xs text-muted-foreground">{item.unidad}</div>
      <div className="text-right font-semibold tabular-nums">{item.subs}</div>
      <div className="flex items-center gap-2">
        <div className="h-1.5 flex-1 rounded-full bg-muted">
          <div className={cn("h-full rounded-full", styles.bar)} style={{ width: `${pct}%` }} />
        </div>
        <span className="w-12 text-right text-xs tabular-nums text-muted-foreground">
          {pct.toFixed(1)}%
        </span>
      </div>
      <div className="flex justify-center">
        {alerted ? (
          <span className="inline-flex items-center gap-1 rounded-md border border-success/30 bg-success/10 px-2 py-1 text-[10px] font-medium text-success">
            <CheckCircle2 className="h-3 w-3" />
            Alertado
          </span>
        ) : (
          <Button onClick={onAlert} disabled={loading} size="sm" variant="outline" className="h-7 gap-1.5 px-2 text-[11px]">
            {loading ? (
              <Loader2 className="h-3 w-3 animate-spin" />
            ) : (
              <Bell className="h-3 w-3" />
            )}
            Alertar
          </Button>
        )}
      </div>
    </div>
  );
}
