import { useState } from "react";
import { Bell, CheckCircle2, AlertTriangle, Package, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { generarNotificacionIA } from "@/lib/gemini.functions";

export interface AlertProduct {
  sku: string;
  name: string;
  presentation: string;
  risk: number;
  stock: number;
  expectedOrders: number;
}

export function AlertCard({ product }: { product: AlertProduct }) {
  const [alerted, setAlerted] = useState(false);
  const [loading, setLoading] = useState(false);
  const callGemini = useServerFn(generarNotificacionIA);

  const severity =
    product.risk >= 70 ? "critical" : product.risk >= 50 ? "high" : "medium";

  const severityStyles = {
    critical: "border-l-primary bg-accent/40",
    high: "border-l-warning bg-warning/5",
    medium: "border-l-chart-2 bg-secondary",
  }[severity];

  const handleAlert = async () => {
    setLoading(true);
    try {
      const res = await callGemini({
        data: {
          tienda: "Don Chuy",
          original: product.name,
          sustituto: `${product.name.split(" ").slice(0, 2).join(" ")} (presentación alternativa)`,
          margen: 8,
        },
      });
      setAlerted(true);
      toast.success("Cliente alertado vía WhatsApp", {
        description: res.mensaje.slice(0, 120) + (res.mensaje.length > 120 ? "…" : ""),
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Error al alertar al cliente");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={cn(
        "rounded-xl border border-border border-l-4 bg-card p-5 shadow-sm transition-shadow hover:shadow-md",
        severityStyles
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Package className="h-5 w-5" />
          </div>
          <div>
            <div className="text-[11px] font-mono uppercase tracking-wider text-muted-foreground">
              SKU {product.sku}
            </div>
            <h3 className="text-base font-semibold leading-tight text-foreground">
              {product.name}
            </h3>
            <p className="text-xs text-muted-foreground">{product.presentation}</p>
          </div>
        </div>
        {severity === "critical" && (
          <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-primary">
            <AlertTriangle className="h-3 w-3" />
            Crítico
          </span>
        )}
      </div>

      <div className="mt-4">
        <div className="mb-1.5 flex items-baseline justify-between">
          <span className="text-xs font-medium text-muted-foreground">
            Riesgo de sustitución
          </span>
          <span className="text-lg font-bold text-foreground">{product.risk}%</span>
        </div>
        <Progress value={product.risk} className="h-2" />
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 rounded-lg bg-muted/50 p-3">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Stock actual
          </div>
          <div className="text-sm font-semibold">{product.stock} cajas</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Pedidos esperados
          </div>
          <div className="text-sm font-semibold">{product.expectedOrders} cajas</div>
        </div>
      </div>

      <div className="mt-4">
        {alerted ? (
          <div className="flex items-center justify-center gap-2 rounded-lg border border-success/30 bg-success/10 px-3 py-2.5 text-sm font-medium text-success">
            <CheckCircle2 className="h-4 w-4" />
            Cliente alertado por WhatsApp
          </div>
        ) : (
          <Button
            onClick={handleAlert}
            disabled={loading}
            variant="default"
            className="w-full gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Enviando…
              </>
            ) : (
              <>
                <Bell className="h-4 w-4" />
                Alertar al Cliente · Sustitución
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}
