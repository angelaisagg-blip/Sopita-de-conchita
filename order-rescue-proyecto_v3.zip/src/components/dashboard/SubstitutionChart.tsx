import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useState } from "react";
import { cn } from "@/lib/utils";

const weeklyData = [
  { day: "Lun", subs: 18, orders: 142 },
  { day: "Mar", subs: 24, orders: 168 },
  { day: "Mié", subs: 31, orders: 175 },
  { day: "Jue", subs: 28, orders: 181 },
  { day: "Vie", subs: 47, orders: 220 },
  { day: "Sáb", subs: 52, orders: 245 },
  { day: "Dom", subs: 12, orders: 88 },
];

const hourlyData = [
  { hour: "08h", subs: 4 },
  { hour: "10h", subs: 9 },
  { hour: "12h", subs: 18 },
  { hour: "14h", subs: 22 },
  { hour: "16h", subs: 15 },
  { hour: "18h", subs: 8 },
  { hour: "20h", subs: 3 },
];

export function SubstitutionChart() {
  const [view, setView] = useState<"week" | "hour">("week");

  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Tendencia de Sustituciones</h2>
          <p className="text-sm text-muted-foreground">
            Identifica los picos de riesgo en el CEDIS
          </p>
        </div>
        <div className="inline-flex rounded-md border border-border bg-muted/40 p-1">
          {(["week", "hour"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={cn(
                "rounded px-3 py-1.5 text-xs font-medium transition-colors",
                view === v
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {v === "week" ? "Semanal" : "Por hora"}
            </button>
          ))}
        </div>
      </div>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {view === "week" ? (
            <BarChart data={weeklyData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip
                cursor={{ fill: "var(--muted)" }}
                contentStyle={{
                  background: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Bar dataKey="subs" fill="var(--primary)" radius={[6, 6, 0, 0]} name="Sustituciones" />
            </BarChart>
          ) : (
            <LineChart data={hourlyData} margin={{ top: 8, right: 16, left: -16, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="hour" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{
                  background: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: 8,
                  fontSize: 12,
                }}
              />
              <Line
                type="monotone"
                dataKey="subs"
                stroke="var(--primary)"
                strokeWidth={3}
                dot={{ fill: "var(--primary)", r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-3 border-t border-border pt-4">
        <Stat label="Pico de riesgo" value="Sábado" sub="52 sustituciones" />
        <Stat label="Hora crítica" value="14:00h" sub="22 sustituciones" />
        <Stat label="Tasa semanal" value="18.5%" sub="vs 12% objetivo" trend="up" />
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  sub,
  trend,
}: {
  label: string;
  value: string;
  sub: string;
  trend?: "up" | "down";
}) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-0.5 text-base font-bold text-foreground">{value}</div>
      <div className={cn("text-xs", trend === "up" ? "text-primary" : "text-muted-foreground")}>
        {sub}
      </div>
    </div>
  );
}
