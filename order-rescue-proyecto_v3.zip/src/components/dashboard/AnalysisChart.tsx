import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import analytics from "@/data/analytics.json";
import { cn } from "@/lib/utils";

type Mode = "sku" | "cedis" | "unidad";

const TABS: { id: Mode; label: string }[] = [
  { id: "sku", label: "Por SKU" },
  { id: "cedis", label: "Por CEDIS" },
  { id: "unidad", label: "Por Unidad" },
];

function truncate(s: string, n = 22) {
  return s.length > n ? s.slice(0, n - 1) + "…" : s;
}

export function AnalysisChart() {
  const [mode, setMode] = useState<Mode>("sku");

  const { data, subtitle, max } = useMemo(() => {
    if (mode === "sku") {
      const d = analytics.topSku.map((r) => ({
        label: `${truncate(r.nombre)} (${r.sku})`,
        value: r.subs,
      }));
      return {
        data: d,
        subtitle: `Top 10 SKUs con más sustituciones · base: ${analytics.totalSubs.toLocaleString()} sustituciones registradas`,
        max: Math.max(...d.map((x) => x.value)),
      };
    }
    if (mode === "cedis") {
      const d = analytics.topCedis.map((r) => ({
        label: `CEDIS ${r.cedis}`,
        value: r.subs,
      }));
      return {
        data: d,
        subtitle: `CEDIS con más sustituciones · base: ${analytics.totalSubs.toLocaleString()} sustituciones registradas`,
        max: Math.max(...d.map((x) => x.value)),
      };
    }
    const d = analytics.topUnidad.map((r) => ({ label: r.unidad, value: r.subs }));
    return {
      data: d,
      subtitle: `Sustituciones por unidad de negocio · base: ${analytics.totalSubs.toLocaleString()} sustituciones registradas`,
      max: Math.max(...d.map((x) => x.value)),
    };
  }, [mode]);

  return (
    <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Análisis de Sustituciones (datos reales)</h2>
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <div className="inline-flex rounded-md border border-border bg-muted/40 p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setMode(t.id)}
              className={cn(
                "rounded px-3 py-1.5 text-xs font-medium transition-colors",
                mode === t.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ height: Math.max(260, data.length * 28 + 40) }} className="w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            layout="vertical"
            margin={{ top: 8, right: 32, left: 8, bottom: 8 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
            <XAxis
              type="number"
              stroke="var(--muted-foreground)"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              domain={[0, Math.ceil(max / 35) * 35]}
            />
            <YAxis
              type="category"
              dataKey="label"
              stroke="var(--muted-foreground)"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              width={140}
            />
            <Tooltip
              cursor={{ fill: "var(--muted)" }}
              contentStyle={{
                background: "var(--card)",
                border: "1px solid var(--border)",
                borderRadius: 8,
                fontSize: 12,
              }}
              formatter={(v: number) => [`${v.toLocaleString()} sustituciones`, ""]}
            />
            <Bar
              dataKey="value"
              fill="var(--primary)"
              radius={[0, 6, 6, 0]}
              barSize={14}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
        Fuente: Resultados.csv cruzado con Orders_filtrado_1.xlsx ({analytics.topCedis.length}+ CEDIS,{" "}
        {analytics.topUnidad.length} unidades de negocio). El CEDIS se atribuye por reparto
        ponderado cuando un <code className="rounded bg-muted px-1">id_pedido</code> aparece en más
        de un centro. No se infieren días/horas porque <code className="rounded bg-muted px-1">fecha_pedido</code>{" "}
        sólo contiene marcas de tiempo parciales.
      </p>
    </div>
  );
}
