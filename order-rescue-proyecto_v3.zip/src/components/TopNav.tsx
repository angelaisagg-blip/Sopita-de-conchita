import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, MessageCircle, ListFilter } from "lucide-react";
import { cn } from "@/lib/utils";

const links = [
  { to: "/", label: "Vista CEDIS", icon: LayoutDashboard },
  { to: "/catalogo", label: "Catálogo de Riesgo", icon: ListFilter },
  { to: "/whatsapp", label: "Simulación WhatsApp", icon: MessageCircle },
] as const;

export function TopNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-card/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-6 px-4 sm:px-6">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold">
            AC
          </div>
          <div className="hidden sm:block">
            <div className="text-sm font-bold leading-tight">Arca Continental</div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
              Order Rescue
            </div>
          </div>
        </div>

        <nav className="ml-4 flex items-center gap-1">
          {links.map((l) => {
            const active = pathname === l.to;
            const Icon = l.icon;
            return (
              <Link
                key={l.to}
                to={l.to}
                className={cn(
                  "inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                )}
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{l.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="ml-auto flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 rounded-full border border-border px-3 py-1.5">
            <span className="h-2 w-2 rounded-full bg-success" />
            <span className="text-xs text-muted-foreground">Sistema activo</span>
          </div>
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-sm font-semibold text-secondary-foreground">
            SV
          </div>
        </div>
      </div>
    </header>
  );
}
